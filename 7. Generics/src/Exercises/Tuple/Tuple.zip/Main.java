import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] nameAddress = scanner.nextLine().split("\\s+");
        String name = nameAddress[0] + " " + nameAddress[1];
        String address = nameAddress[2];
        Tuple<String, String> personData = new Tuple<>(name,address);
        System.out.println(personData);

        String[] nameLitresOfBeer = scanner.nextLine().split("\\s+");
        name = nameLitresOfBeer[0];
        Integer litresOfBeer = Integer.valueOf(nameLitresOfBeer[1]);
        Tuple<String, Integer> drinkerData = new Tuple<>(name, litresOfBeer);
        System.out.println(drinkerData);

        String[] intAndDouble = scanner.nextLine().split("\\s+");
        int intNum = Integer.parseInt(intAndDouble[0]);
        double floatNum = Double.parseDouble(intAndDouble[1]);
        Tuple<Integer, Double> numbers = new Tuple<>(intNum, floatNum);
        System.out.println(numbers);
    }
}
